

import javax.swing.*;
import java.awt.*;
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Color;

/// Julia set class
class Julia extends JFrame {
	double coreal;   // constant real part 
	double coimag;   // constant imaginery part
	
	
	public Julia (){
	  this.coreal=-0.4;        // assigning value to real part of resl constant and imaginery constant 
	  this.coimag= 0.6;
	}
	
	public Julia(double coreal,double coimag){
		  this.coreal=coreal;
		  this.coimag=coimag;
	}
	  
    // calculate the iteration and find the complex plane	  
	public int mathematic(int i,int j){
		// int  iterations;
		 double y_im;
	     double x_re;
		 double tem;                               // temperary variable   
					x_re=((double)i-400)/400;
					y_im=(400-(double)j)/400;
						int it=0;
						int itmax=1000;
						
						while (it<itmax){
							tem=x_re*x_re-y_im*y_im;
							y_im=2*x_re*y_im+coimag;
							x_re=tem+coreal;
							it++;
							if((x_re*x_re+y_im*y_im)>4){break;}
							
						}
						 return it;
			          
    }
	// get the frame and and color  
	 public void picture(){
		 JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(800, 800);
		 JPanel panel = new JPanel(){
		
		 @Override
         public  void paintComponent(Graphics g) {
				
                super.paintComponent(g);    
	              
				 for(int i=0;i<=800;i++){
					for(int j=0;j<=800;j++){
						Color myColour =new Color(mathematic(i,j)%255,0,mathematic(i,j)%182);
				    
						g.setColor(myColour);
						g.fillRect(i,j, 2,2);}	   						
				 }
		 }
	 };
	 frame.add(panel);

   }
}