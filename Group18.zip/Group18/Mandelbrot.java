import javax.swing.*;
import java.awt.*;
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Color;
class Mandelbrot{
	
	double coreal;
	double coimag;
	double itmax;
	double opx1;
    double opx2;
    double opy1;
    double opy2;
	
	public Mandelbrot(){
		 this.opx1=-1;
		 this.opx2= 1;
		 this.opy1=-1;
		 this.opy2=1;
		 this.itmax=1000;
	  }
	  
	  public Mandelbrot(double opx1,double opx2,double opy1,double opy2){
		 
		 this.opx1=opx1;
		 this.opx2=opx2;
		 this.opy1=opy1;
		 this.opy2=opy2;
		 this.itmax=1000;
	  }
	  public Mandelbrot(double opx1,double opx2,double opy1,double opy2,double itmax){
		 
		 this.opx1=opx1;
		 this.opx2=opx2;
		 this.opy1=opy1;
		 this.opy2=opy2;
		 this.itmax=itmax;
	  }
	     
	 public int mathematic(int i,int j){
		// int  iterations;
		 double y;
	     double x;
					
					x = ((double) i / 800) * (opx2 - opx1) + (opx1);
                    y = -opy2 + ((double) j / 800) * (opy2 - opy1);
               

						coreal=x;
					    coimag=y;
						
						int it=0;	
						
						while (it<itmax){
							double x1=x*x-y*y+coreal;
							y=2*x*y+coimag;
							x=x1;
							it++;
							if(Math.abs(x*x+y*y)>4){
								break;
								}
							
						}
                      
						 return it;
			          
    }
	 public void picture(){
		 JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(800, 800);
		
	  JPanel panel = new JPanel(){
		
		 @Override
         public  void paintComponent(Graphics g) {
				
                super.paintComponent(g);    
				 for(int i=0;i<=800;i++){
					for(int j=0;j<=800;j++){
						
				    Color myColour =new Color(mathematic(i,j)%50,0,mathematic(i,j)%150);
				    
						g.setColor(myColour);
						g.fillRect(i,j, 2,2);
				   }							
				 }
		 }		
		};
		frame.add(panel);

	 }
}