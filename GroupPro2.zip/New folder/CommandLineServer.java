

public class CommandLineServer { 
    public static void main(String [] args) { 
	CompanyDB allowedUsers = new CompanyDB("stocks.csv","Symbol","Price");
	MainServer mainServer = new MainServer(MainServer.BASE_PORT,
					       allowedUsers); 
	mainServer.server_loop(); 
    }
}
	