
import java.io.*;
import java.util.*;

class CompanyDB {

    private Map<String, LinkedList> classList;
    private String[] fields;
    private LinkedList list;

    public CompanyDB(String cvsFile, String key, String val) {
        FileReader fileRd = null;
        BufferedReader reader = null;

        try {
            fileRd = new FileReader(cvsFile);
            reader = new BufferedReader(fileRd);

            /* read the CSV file's first line which has 
             * the names of fields. 
             */
            String header = reader.readLine();
            fields = header.split(",");// keep field names 

            // find where the key and the value are 
            int keyIndex = findIndexOf(key);
            int valIndex = findIndexOf(val);

            if (keyIndex == -1 || valIndex == -1) {
                throw new IOException("CVS file does not have data");
            }
	    // note how you can throw a new exception 

            // get a new hash map
            classList = new HashMap<>();

            /* read each line, getting it split by , 
             * use the indexes to get the key and value 
             */
            String[] tokens;
            for (String line = reader.readLine();
                    line != null;
                    line = reader.readLine()) {
                tokens = line.split(",");
                classList.put(tokens[keyIndex], list = new LinkedList());
                try {
                    list.addLast(Double.parseDouble(tokens[valIndex]));
                } catch (NumberFormatException e) {
                    System.out.println(tokens[keyIndex]);
                }
                
            }

            if (fileRd != null) {
                fileRd.close();
            }
            if (reader != null) {
                reader.close();
            }

            // I can catch more than one exceptions 
        } catch (IOException e) {
            System.out.println(e);
            System.exit(-1);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Malformed CSV file");
            System.out.println(e);
        }
    }

    private int findIndexOf(String key) {
        int i =0;
        for (String field : fields) {
            String s = field;
            if (s.trim().equalsIgnoreCase(key)) {
                return i;
            }
            i++;
        }
        return -1;
    }

    // public interface 
    public Double findSymbol(String key) {
        try {
            if (classList.containsKey(key)) {
                return (Double) classList.get(key).getLast();
            }
        } catch (NoSuchElementException e) {
            return -1.0;
        }
        return -1.0;
    }
    
    public boolean changePrice(Double bid, String key){
        classList.get(key).addLast(bid);
        return true;
    }
}
