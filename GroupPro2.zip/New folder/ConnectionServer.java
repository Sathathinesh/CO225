
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

class ConnectionServer implements Runnable {

    // some constants 
    public static final int WAIT_AUTH_NAME = 0;
    public static final int WAIT_AUTH_SYM = 2;
    public static final int AUTH_DONE = 1;

    public static final String WAIT_AUTH_NAME_MSG = "Name of the bidder \n";
    public static final String WAIT_AUTH_SYM_MSG = "Invalid Symbol\n";
    public static String AUTH_DONE_MSG = "Your bid :\t";
    public static final String MSG_POSTED = "Your bid is invalid\n";

    // per connection variables
    private Socket mySocket; // connection socket per thread 
    private int currentState, bid;
    private String clientName, Company, print = "";
    private Double Price;
    private MainServer mainServer;
    private Table table;
	private Tab tab;

    public ConnectionServer(MainServer mainServer) {
        this.mySocket = null; // we will set this later 
        this.currentState = WAIT_AUTH_NAME;
        this.clientName = null;
        this.mainServer = mainServer;
        // who created me. He should give some interface 
    }

    public boolean handleConnection(Socket socket) {
        this.mySocket = socket;
        table = new Table();
		tab = new Tab();
        table.setVisible(true);
		
        Thread newThread = new Thread(this);
        newThread.start();
        return true;
    }

    public void run() { // can not use "throws .." interface is different
        BufferedReader in = null;
        PrintWriter out = null;
        try {
            in = new BufferedReader(new InputStreamReader(mySocket.getInputStream()));
            out = new PrintWriter(new OutputStreamWriter(mySocket.getOutputStream()));

            String line, outline = "";
            for (line = in.readLine(); line != null && !line.equals("quit"); line = in.readLine()) {

                switch (currentState) {
                    case WAIT_AUTH_NAME:
                        currentState = WAIT_AUTH_SYM;
                        clientName = line;
                        break;
                    case WAIT_AUTH_SYM:
                        Price = mainServer.isAuthorized(line);
                        if (Price != -1) {
                            currentState = AUTH_DONE;
                            Company = line;
                            outline = AUTH_DONE_MSG;
                            int id = mainServer.getCompany(Company);
							
                            if (id != -1) {
                                this.table.price[id] = Price;
                            }
                            System.out.println("Current cost :\t" + Price);
                        } else {
                            outline = WAIT_AUTH_SYM_MSG;
                        }
                        break;
                    case AUTH_DONE:
                        try {
                            double bid = Double.parseDouble(line);

                            if (mainServer.bid(bid, Company)) {
                                mainServer.postMSG(this.clientName + "'s bid on " + Company + " is : " + line);
                                int id = mainServer.getCompany(Company);
                                if (id != -1) {
                                    this.table.price[id] = bid;
									//th
                                }
                                outline = AUTH_DONE_MSG;
								break;
                            }
                        } catch (NumberFormatException e) {
                            outline = MSG_POSTED;
                        }
                        break;
                    default:
                        System.out.println("Undefined state");
                        return;
                } // case 

                out.print(outline); // Send the said message 
                out.flush(); // flush to network

            } // for 

            // close everything 
            out.close();
            in.close();
            this.mySocket.close();
        } // try 	     
        catch (IOException e) {
            System.out.println(e);
        }
    }
}
