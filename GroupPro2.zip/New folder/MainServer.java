
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MainServer {

    /* Some constants */
    public static final int BASE_PORT = 2000;  // do not change    


    /* local data for the server 
     * Every main server is defined in terms of the port it 
     * listens and the database of allowed users 
     */
    private ServerSocket serverSocket = null;  // server Socket for main server 
    private CompanyDB allowedUsers = null;     // who are allowed to chat 

    public MainServer(int socket, CompanyDB users) {
        this.allowedUsers = users;

        try {
            this.serverSocket = new ServerSocket(socket);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    /* each server will provide the following functions to 
     * the public. Note that these are non-static 
     */
    public Double isAuthorized(String symbol) {
        return this.allowedUsers.findSymbol(symbol);
    }

    public int getCompany(String Company) {
        int id = -1;
       
            if(Company.equals("FB")) 
			{id = 0;}
		else if(Company.equals("GOOGL")) 
			{id = 1;}
        else if(Company.equals("MSFT")) 
			{id = 2;}
        else if(Company.equals("VRTU")) 
			{id = 3;}
        else if(Company.equals("TSLA")) 
			{id = 4;}
		else if(Company.equals("TXN")) 
			{id = 5;}
        else if(Company.equals("XLNX")) 
			{id = 6;}
        else if(Company.equals("YHOO")) 
			{id = 7;}
        
    
        
        return id;
    }
    /* server will define how the messages should be posted 
     * this will be used by the connection servers
     */

    public synchronized boolean bid(Double bid, String key) {
        return this.allowedUsers.changePrice(bid, key);
    }

    public void postMSG(String msg) {
        // all threads print to same screen 
        System.out.println(msg);
    }

    public String authorizedOnce(String a) {
        // need to implement this. 
        return null;
    }

    public void server_loop() {
        try {
            while (true) {
                Socket socket = this.serverSocket.accept();
                ConnectionServer worker = new ConnectionServer(this);
                worker.handleConnection(socket);
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }// end server_loop 
}
