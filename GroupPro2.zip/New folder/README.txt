e/15/366 and E/15/373 group project 2

1. first compile and run CommandLineServer.java, then connect to the IP with port number 2000.

2. After connected ,  you should enter your name, and press enter !

3.then you should enter symbol (eg : FB,TXN,GOOGL) and press enter.

4. IF you entered a valid symbol, it displays " your  bid :" in the cliend side and then you enter the bid ,

5. then you should enter a bid, then sever side " cliend name + bid on + symbol + price"
	
6. in the gui it will show that 8 symbols, name  and prices in the table format.