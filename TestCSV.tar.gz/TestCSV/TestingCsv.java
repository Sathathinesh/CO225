import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*; 

public class TestingCsv {
    String lName = "L:";
	String fName = "F:" ;
	String name ;
    String line = null;
	String fname;
	
	public static void main(String[] args) {

	String filname ="contacts001.csv";
	New op =new New(args[0], filname);
	op.printnumber();

 }
}
class New extends TestingCsv{
	
	
	public New (String name, String fname){
	 this.name=name	;
	 this.fname=fname;	
	}
	
	public void printnumber(){
		try { 	 

	//reading file
      BufferedReader in = new BufferedReader( new FileReader(fname)); 
	    	   
	   while ((line = in.readLine()) != null) {	 	

	   	String parts[] = line.split(",");

	   	if(fName.compareTo(name.substring(0,2))==0){
		  	if (parts[0].compareTo(name.substring(2))==0) {
		  		 System.out.println(parts[20]);
				 System.exit(0);
		  	}else{
            //System.out.println("No such input");
				//System.exit(0);
		  	}
		}
        else if(lName.compareTo(name.substring(0,2))==0){
		  	if (parts[2].compareTo(name.substring(2))==0) {
		  		 System.out.println(parts[20]);
				  System.exit(0);
		  	}
		  	else{
				//System.out.println("No such input");
				//System.exit(0);
        	}
		}
		else {
			System.out.println("wrong input");
				System.exit(0);
		}
	  	 
	}
	  in.close();   
	} catch(Exception e) { 
	        System.out.println("Bad things happen, what do you do!" + e);
	  
	}

	}
}
