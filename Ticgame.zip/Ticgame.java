
import javax.swing.JOptionPane;

/**
 *
 * @author Thinesh
 */
public class Ticgame extends javax.swing.JFrame {
     private String startGame="1";                      // Player 1 start the game 
     private int gameCo=0;                              // used to count the click
    
    public Ticgame() {
        initComponents();
        setSize(400,400);                              // fram in 400 and 400
        setLocationRelativeTo(null);
    }
    
           	                                           //  reset the game 
	private  void clearGrid(){
	 jButton10.setText("");
         jButton2.setText("");
         jButton3.setText("");
         jButton4.setText("");
         jButton5.setText("");
         jButton6.setText("");
         jButton7.setText("");
         jButton8.setText("");
         jButton9.setText("");
         gameCo=0;
         startGame="1";
         
    }
			
		

     private void winGame(){
        String b1 = jButton2.getText();
        String b2 = jButton3.getText();
        String b3 = jButton4.getText();
        String b4 = jButton5.getText();
        String b5 = jButton6.getText();
        String b6 = jButton7.getText();
        String b7 = jButton8.getText();
        String b8 = jButton9.getText();
        String b9 = jButton10.getText();
      //  String b1 = jButton1.getText();
      
        if ("1".equals(b1) && "1".equals(b2) && "1".equals(b3)) {
         
           int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 1 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                clearGrid();
	   }
        }
        else if ("1".equals(b4) && "1".equals(b5) && "1".equals(b6)) {
          
            int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 1 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
        }
        else if ("1".equals(b7) && "1".equals(b8) && "1".equals(b9)) {
          //  gameScore1();
            int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 1 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
            
        }
        else if ("1".equals(b1) && "1".equals(b4) && "1".equals(b7)) {
           // gameScore1();
             int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 1 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
        }
        else if ("1".equals(b2) && "1".equals(b5) && "1".equals(b8)) {
          //  gameScore1();
            int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 1 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
           
        }
        else if ("1".equals(b9) && "1".equals(b3) && "1".equals(b6)) {
          //  gameScore1();
            int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 1 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
       
        } 
        else if ("1".equals(b1) && "1".equals(b5) && "1".equals(b9)) {
           // gameScore1();
             int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 1 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
            
        }
        else if ("1".equals(b7) && "1".equals(b5) && "1".equals(b3)) {
           // gameScore1();
             int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 1 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
        } 
         
        else if ("2".equals(b1) && "2".equals(b2) && "2".equals(b3)) {
           // gameScore2();
             int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 2 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
        }
        else if ("2".equals(b4) && "2".equals(b5) && "2".equals(b6)) {
            //gameScore2();
                int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 2 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
         
        }
        else if ("2".equals(b7) && "2".equals(b8) && "2".equals(b9)) {
           // gameScore2();
               int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 2 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
         
        }
        else if ("2".equals(b1) && "2".equals(b4) && "2".equals(b7)) {
           // gameScore2();
               int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 2 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
         
        }
        else if ("2".equals(b2) && "2".equals(b5) && "2".equals(b8)) {
          //  gameScore2();
              int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 2 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
            
        }
        else if ("2".equals(b9) && "2".equals(b3) && "2".equals(b6)) {
           // gameScore2();
               int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 2 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
        
        } 
        else if ("2".equals(b1) && "2".equals(b5) && "2".equals(b9)) {
           // gameScore2();
               int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 2 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
       
        }
        else if ("2".equals(b7) && "2".equals(b5) && "2".equals(b3)) {
            //gameScore2();
                int x= JOptionPane.showConfirmDialog(this, "<html>PLAYER 2 WON THE GAME !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
          
           
        }
        else if (gameCo==9)                         // if click ==9 and there are no  win then game tie
        {
            int x= JOptionPane.showConfirmDialog(this, "<html> THE GAME TIE !<br>DO YOU WANT TO PLAY AGAIN ?<br></html>","Alert", JOptionPane.YES_NO_OPTION);
          
             if (x==JOptionPane.NO_OPTION) {		// To close the frame window
			   System.exit(0);
	   }
            else if (x==JOptionPane.YES_OPTION) {		// To reset the frame window
			   //System.exit(0);
                           clearGrid();
	   }
            
        }
            
      
    }
    
  // choose the player 
   
 private void choosePlayer(){
       
       if (gameCo%2==0){
           startGame="1";
           
       }
       else 
           startGame="2";
   }  
   
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TicTacToe");

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setLayout(new java.awt.GridLayout(3, 3, 2, 2));

        jPanel2.setLayout(new java.awt.BorderLayout());

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 55)); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel2);

        jPanel3.setLayout(new java.awt.BorderLayout());

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 55)); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel3);

        jPanel4.setLayout(new java.awt.BorderLayout());

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 55)); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton4, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel4);

        jPanel5.setLayout(new java.awt.BorderLayout());

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 55)); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton5, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel5);

        jPanel6.setLayout(new java.awt.BorderLayout());

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 55)); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton6, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel6);

        jPanel7.setLayout(new java.awt.BorderLayout());

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 55)); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton7, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel7);

        jPanel8.setLayout(new java.awt.BorderLayout());

        jButton8.setFont(new java.awt.Font("Tahoma", 1, 55)); // NOI18N
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton8, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel8);

        jPanel9.setLayout(new java.awt.BorderLayout());

        jButton9.setFont(new java.awt.Font("Tahoma", 1, 55)); // NOI18N
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton9, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel9);

        jPanel10.setLayout(new java.awt.BorderLayout());

        jButton10.setFont(new java.awt.Font("Tahoma", 1, 55)); // NOI18N
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton10, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel10);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>                        

 private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
         // if(jButton2.getText()==null){
              
              choosePlayer();
              if("".equals(jButton2.getText())){
              jButton2.setText(startGame);
              gameCo++;
              }
            //}
              winGame();
          
    }                                        

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
           choosePlayer();
              if("".equals(jButton4.getText())){
              jButton4.setText(startGame);
              gameCo++;
              }
            //}
              winGame();
    }                                        

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
         choosePlayer();
              if("".equals(jButton7.getText())){
              jButton7.setText(startGame);
              gameCo++;
              }
            //}
              winGame();
    }                                        

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {                                          
        // TODO add your handling code here:
            choosePlayer();
              if("".equals(jButton10.getText())){
              jButton10.setText(startGame);
              gameCo++;
              }
            //}
              winGame();
    }                                         

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
            choosePlayer();
              if("".equals(jButton3.getText())){
              jButton3.setText(startGame);
              gameCo++;
              }
            //}
              winGame();
    }                                        

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
           choosePlayer();
              if("".equals(jButton5.getText())){
              jButton5.setText(startGame);
              gameCo++;
              }
            //}
              winGame();
    }                                        

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
           choosePlayer();
              if("".equals(jButton6.getText())){
              jButton6.setText(startGame);
              gameCo++;
              }
            //}
              winGame();
    }                                        

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
           choosePlayer();
              if("".equals(jButton8.getText())){
              jButton8.setText(startGame);
              gameCo++;
              }
            //}
              winGame();
    }                                        

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
            choosePlayer();
              if("".equals(jButton9.getText())){
              jButton9.setText(startGame);
              gameCo++;
              }
            //}
              winGame();
    } 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ticgame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ticgame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ticgame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ticgame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ticgame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    // End of variables declaration                   
}
