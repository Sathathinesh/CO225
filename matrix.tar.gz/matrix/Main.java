public class Main {
    
    public static int [][] A = {{1, 1, 1},
    {1, 1, 1},
    {1, 1, 1}};

     public static int [][] B = {{1 },{1 },{1 }};
     
 public static void print_matrix(int [][] a) {
     for(int i=0; i < a.length; i++) {
      for(int j=0; j< a[i].length; j++) {
         System.out.print(a[i][j] + " "); 
      }
          System.out.println();
      }
      }                          

  //  public static final int NUM_OF_THREADS = B.length;

    static int C[][] = new int[A.length][B[0].length];
    public static void main(String args[])
    {
        int row;
        int col;
    
        int count = 0;   
              Thread[] thre = new Thread[B.length];
               

                    //   use threads to parallelize the operation
                    //   row =3 and column=1 so we use 3 threads in 3 different times 
                    // in each row using different thread 

                   for(row = 0 ; row < A.length; row++)
                   {
                        for (col = 0 ; col < B[0].length; col++ )
                        {
                                // creating thread for multiplications
                             thre[count] = new Thread(new Matrix( A, B, C));
                             thre[count].start(); //thread start 
                              count++;
                        }
                        
                   }
                   // joining threads
                   for(int i=0; i<count; i++){  
                
                    try{
                    
                          thre[i].join();
                    
                     }catch (InterruptedException e){
                    
                       //thread was interrupted
                    
                     }
                    
                    }
                
                print_matrix(C);
                    
    }
    
}



class Matrix implements Runnable
{
    private static int A[][];
    private static int B[][];
    private static int C[][];
    
    public Matrix( int A[][], int B[][], int C[][] )
    {
        this.A = A;
        this.B = B;
        this.C = C;
    }
    
   // @Override

    public synchronized static int [][] multiplyMatrix()
   // public void run()
    {       
    int x = A.length; 
	int y = B[0].length; 

	int z1 = A[0].length; 
	int z2 = B.length; 

	if(z1 != z2) { 
	    System.out.println("Cannnot multiply");
	    return null;
	}

//	int [][] c = new int [x][y]; 
	int i, j, k, s; 

	for(i=0; i<x; i++) 
	    for(j=0; j<y; j++) {
		for(s=0, k=0; k<z1; k++) 
		    s += A[i][k] * B[k][j];
		C[i][j] = s;
	    }

	return C; 
    }
    @Override
    public void run() {
	   //  System.out.println(Thread.currentThread().getName()+d[0].length);
         C=multiplyMatrix();
                     
    }
} 

// Answers 
/* 
*****************************************************************************************************
 Multi-threaded programs may often come to a situation where multiple threads
 try to access the same resources and finally produce erroneous and unforeseen results.
 So it needs to be made sure by some synchronization method that only 
 one thread can access the resource at a given point of time.
 ****************************************************************************************************
*****************************************************************************************************
*/
