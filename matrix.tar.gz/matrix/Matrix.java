class Matrix implements Runnable
{
    private static int A[][];
    private static int B[][];
    private static int C[][];
    
    public Matrix( int A[][], int B[][], int C[][] )
    {
        this.A = A;
        this.B = B;
        this.C = C;
    }
    
   // @Override

    public synchronized static int [][] multiplyMatrix()
   // public void run()
    {       
    int x = A.length; 
	int y = B[0].length; 

	int z1 = A[0].length; 
	int z2 = B.length; 

	if(z1 != z2) { 
	    System.out.println("Cannnot multiply");
	    return null;
	}

//	int [][] c = new int [x][y]; 
	int i, j, k, s; 

	for(i=0; i<x; i++) 
	    for(j=0; j<y; j++) {
		for(s=0, k=0; k<z1; k++) 
		    s += A[i][k] * B[k][j];
		C[i][j] = s;
	    }

	return C; 
    }
    @Override
    public void run() {
	   //  System.out.println(Thread.currentThread().getName()+d[0].length);
         C=multiplyMatrix();
                     
    }
} 

// Answers 
/* 
*****************************************************************************************************
 Multi-threaded programs may often come to a situation where multiple threads
 try to access the same resources and finally produce erroneous and unforeseen results.
 So it needs to be made sure by some synchronization method that only 
 one thread can access the resource at a given point of time.
 ****************************************************************************************************
*****************************************************************************************************
*/
